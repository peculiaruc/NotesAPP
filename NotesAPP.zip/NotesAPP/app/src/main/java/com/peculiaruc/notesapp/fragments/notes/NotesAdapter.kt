package com.peculiaruc.notesapp.fragments.notes

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.peculiaruc.notesapp.R

class NotesAdapter(private val note: MutableList<Note> = mutableListOf()):
        RecyclerView.Adapter<RecyclerView.ViewHolder>()  {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder =
            ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.list_notes, parent,
                    false))

    override fun getItemCount(): Int = note.size

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

    }

    class ViewHolder(val view: View): RecyclerView.ViewHolder(view) {

        fun onBind() {

        }
    }
}